#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "esp_zigbee_core.h"
#include "ha/esp_zigbee_ha_standard.h"
#include "ZigbeeCoordinator.h"
#include "Config.h"

static const char *TAG = "ZB_COORD";

#define COORDINATOR_ENDPOINT 1
#define LIGHT_ENDPOINT 10
#define BUTTON_GPIO 28

static uint16_t joined_device_short_addr[MAX_CHILDREN];
static uint8_t joined_device_count = 0;
static bool light_state = false;

void esp_zb_app_signal_handler(esp_zb_app_signal_t *signal_struct) {
    uint32_t *p_sg_p = signal_struct->p_app_signal;
    esp_err_t err_status = signal_struct->esp_err_status;
    esp_zb_app_signal_type_t sig = *p_sg_p;

    switch (sig) {
        case ESP_ZB_ZDO_SIGNAL_SKIP_STARTUP:
            ESP_LOGI(TAG, "Zigbee stack initialized");
            esp_zb_bdb_start_top_level_commissioning(ESP_ZB_BDB_MODE_INITIALIZATION);
            break;

        case ESP_ZB_BDB_SIGNAL_DEVICE_FIRST_START:
        case ESP_ZB_BDB_SIGNAL_DEVICE_REBOOT:
            if (err_status == ESP_OK) {
                ESP_LOGI(TAG, "Coordinator started");
                esp_zb_bdb_start_top_level_commissioning(ESP_ZB_BDB_MODE_NETWORK_FORMATION);
            } else {
                ESP_LOGE(TAG, "Startup failed: %s", esp_err_to_name(err_status));
            }
            break;

        case ESP_ZB_BDB_SIGNAL_FORMATION:
            if (err_status == ESP_OK) {
                ESP_LOGI(TAG, "Network formed");
                ESP_LOGI(TAG, "PAN ID: 0x%04x", esp_zb_get_pan_id());
                ESP_LOGI(TAG, "Channel: %d", esp_zb_get_current_channel());
                ESP_LOGI(TAG, "Short Addr: 0x%04x", esp_zb_get_short_address());
                esp_zb_bdb_start_top_level_commissioning(ESP_ZB_BDB_MODE_NETWORK_STEERING);
            }
            break;

        case ESP_ZB_BDB_SIGNAL_STEERING:
            if (err_status == ESP_OK) {
                ESP_LOGI(TAG, "Network open for joining");
                esp_zb_bdb_open_network(PERMIT_JOIN_DURATION);
            }
            break;

        case ESP_ZB_ZDO_SIGNAL_DEVICE_ANNCE: {
            esp_zb_zdo_signal_device_annce_params_t *dev =
                (esp_zb_zdo_signal_device_annce_params_t *)esp_zb_app_signal_get_params(p_sg_p);
            ESP_LOGI(TAG, "Device joined! Short Addr: 0x%04x", dev->device_short_addr);

            if (joined_device_count < MAX_CHILDREN) {
                joined_device_short_addr[joined_device_count++] = dev->device_short_addr;
            }
            break;
        }

        case ESP_ZB_ZDO_SIGNAL_LEAVE: {
            ESP_LOGW(TAG, "Device left network");
            joined_device_count = 0;
            break;
        }

        default:
            ESP_LOGD(TAG, "Signal: %d", sig);
            break;
    }
}

static esp_zb_ep_list_t *create_coordinator_endpoint(void) {
    esp_zb_on_off_switch_cfg_t switch_cfg = ESP_ZB_DEFAULT_ON_OFF_SWITCH_CONFIG();
    esp_zb_ep_list_t *ep_list = esp_zb_on_off_switch_ep_create(COORDINATOR_ENDPOINT, &switch_cfg);
    esp_zb_device_register(ep_list);
    ESP_LOGI(TAG, "Coordinator endpoint created");
    return ep_list;
}

void zigbee_coordinator_init(void) {
    esp_zb_platform_config_t platform_cfg = {
        .radio_config = { .radio_mode = ZB_RADIO_MODE_NATIVE },
        .host_config = { .host_connection_mode = ZB_HOST_CONNECTION_MODE_NONE },
    };
    ESP_ERROR_CHECK(esp_zb_platform_config(&platform_cfg));

    esp_zb_cfg_t zb_nwk_cfg = {
        .esp_zb_role = ESP_ZB_DEVICE_TYPE_COORDINATOR,
        .install_code_policy = false,
        .nwk_cfg = {
            .zczr_cfg = {
                .max_children = MAX_CHILDREN,
            },
        },
    };

    esp_zb_init(&zb_nwk_cfg);
    create_coordinator_endpoint();
    esp_zb_set_channel_mask(1UL << ZIGBEE_CHANNEL);

    ESP_ERROR_CHECK(esp_zb_start(false));
}

/*void esp_zb_task(void *pvParameters) {// edited at 5:17 pm 25 Aug
    zigbee_coordinator_init();
    esp_zb_stack_main_loop();
    vTaskDelete(NULL);
} */
void esp_zb_task(void *pvParameters) {
    zigbee_coordinator_init();
    
    // ✅ Instead of esp_zb_stack_main_loop() which blocks forever,
    // use esp_zb_main_loop_iteration() with a delay
    while (1) {
        esp_zb_main_loop_iteration();   // Process one iteration
        vTaskDelay(pdMS_TO_TICKS(10));  // Yield CPU to prevent watchdog
    }
    
    vTaskDelete(NULL);  // This will never be reached
}
void button_task(void *pvParameters) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << BUTTON_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    gpio_config(&io_conf);

    ESP_LOGI(TAG, "Button task started on GPIO %d", BUTTON_GPIO);

    while (1) {
        if (gpio_get_level(BUTTON_GPIO) == 0) {
            vTaskDelay(pdMS_TO_TICKS(50));
            if (gpio_get_level(BUTTON_GPIO) == 0) {
                ESP_LOGI(TAG, "Button pressed - toggling light");
                light_state = !light_state;

                if (joined_device_count > 0) {
                    esp_zb_zcl_on_off_cmd_t cmd_req = {
                        .zcl_basic_cmd = {
                            .dst_addr_u.addr_short = joined_device_short_addr[0],
                            .dst_endpoint = LIGHT_ENDPOINT,
                            .src_endpoint = COORDINATOR_ENDPOINT,
                        },
                        .address_mode = ESP_ZB_APS_ADDR_MODE_16_ENDP_PRESENT,
                        .on_off_cmd_id = light_state ? ESP_ZB_ZCL_CMD_ON_OFF_ON_ID : ESP_ZB_ZCL_CMD_ON_OFF_OFF_ID,
                    };
                    esp_zb_lock_acquire(portMAX_DELAY);
                    esp_zb_zcl_on_off_cmd_req(&cmd_req);
                    esp_zb_lock_release();
                }

                while (gpio_get_level(BUTTON_GPIO) == 0) {
                    vTaskDelay(pdMS_TO_TICKS(10));
                }
            }
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}