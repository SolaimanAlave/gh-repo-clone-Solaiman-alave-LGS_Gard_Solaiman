/*#include "MqttManager.h"
#include "Config.h"
#include "esp_log.h"
#include <ArduinoJson.h>
#include <Arduino.h>

static const char* TAG = "MQTT_MGR";

MqttManager& MqttManager::instance() {
    static MqttManager inst;
    return inst;
}

void MqttManager::begin(const char* broker, uint16_t port, const char* clientId) {
    _broker = broker;
    _port = port;
    _clientId = clientId;
    
    // Connect WiFiClient to PubSubClient
    _mqttClient.setClient(_wifiClient);
    
    _mqttClient.setServer(_broker, _port);
    _mqttClient.setCallback(mqttCallback);
    _mqttClient.setSocketTimeout(30);
    _mqttClient.setKeepAlive(60);
    
    ESP_LOGI(TAG, "Configured broker: %s:%d", _broker, _port);
}

bool MqttManager::publishSensorData(const SensorData& data) {
    if (!_mqttClient.connected()) {
        ESP_LOGW(TAG, "Not connected, skipping publish.");
        return false;
    }

    JsonDocument doc;
    doc["unit"] = 1;
    doc["tempLF"] = data.tempLF;
    doc["humLF"] = data.humLF;
    doc["tempLB"] = data.tempLB;
    doc["humLB"] = data.humLB;
    doc["waterPct"] = data.waterLevelPct;
    doc["waterTemp"] = data.waterTemp;
    doc["pH"] = data.pH;
    doc["tds"] = data.tds;
    doc["fanLF"] = data.fanLF_on;
    doc["fanLB"] = data.fanLB_on;
    doc["lightLF"] = data.lightLF_on;
    doc["lightLB"] = data.lightLB_on;

    char payload[512];
    serializeJson(doc, payload, sizeof(payload));

    bool ok = _mqttClient.publish(TOPIC_PUBLISH, payload);
    if (ok) {
        ESP_LOGI(TAG, "Published to '%s': %s", TOPIC_PUBLISH, payload);
    } else {
        ESP_LOGW(TAG, "Publish failed. State: %d", _mqttClient.state());
    }
    return ok;
}

void MqttManager::maintain() {
    if (!_mqttClient.connected()) {
        reconnect();
    }
    _mqttClient.loop();
}

bool MqttManager::isConnected()  {
    return _mqttClient.connected();
}

int MqttManager::getState() {      
    return _mqttClient.state();
}

bool MqttManager::reconnect() {
    if (_mqttClient.connected()) return true;

    ESP_LOGI(TAG, "Connecting to %s:%d as %s...", _broker, _port, _clientId);
    
    if (_mqttClient.connect(_clientId)) {
        ESP_LOGI(TAG, "Connected!");
        _mqttClient.subscribe(TOPIC_SUBSCRIBE);
        return true;
    }

    int state = _mqttClient.state();
    ESP_LOGW(TAG, "Failed. State: %d", state);
    // PubSubClient states:
    // -4: MQTT_CONNECTION_TIMEOUT
    // -3: MQTT_CONNECTION_LOST
    // -2: MQTT_CONNECT_FAILED
    // -1: MQTT_DISCONNECTED
    // 0: MQTT_CONNECTED
    // 1: MQTT_CONNECT_BAD_PROTOCOL
    // 2: MQTT_CONNECT_BAD_CLIENT_ID
    // 3: MQTT_CONNECT_UNAVAILABLE
    // 4: MQTT_CONNECT_BAD_CREDENTIALS
    // 5: MQTT_CONNECT_UNAUTHORIZED
    return false;
}

void MqttManager::mqttCallback(char* topic, byte* payload, unsigned int length) {
    ESP_LOGI(TAG, "Message received on %s", topic);
    // Add your command handling here
} */ // This is the previous content of the file esp32_firmware/lgs_coordinator/main/MqttManager.cpp, which has been commented out.at 2.31 pm sept 10.

/*#include "MqttManager.h"
#include "Config.h"
#include "esp_log.h"
#include <ArduinoJson.h>
#include <Arduino.h>

static const char* TAG = "MQTT_MGR";

MqttManager& MqttManager::instance() {
    static MqttManager inst;
    return inst;
}

void MqttManager::begin(const char* broker, uint16_t port, const char* clientId) {
    _broker = broker;
    _port = port;
    _clientId = clientId;
    
    _mqttClient.setClient(_wifiClient);
    _mqttClient.setServer(_broker, _port);
    _mqttClient.setCallback(mqttCallback);
    _mqttClient.setSocketTimeout(30);
    _mqttClient.setKeepAlive(60);
    
    ESP_LOGI(TAG, "Configured broker: %s:%d", _broker, _port);
}

bool MqttManager::publishSensorData(const SensorData& data) {
    JsonDocument doc;
    doc["unit"] = 1;
    doc["tempLF"] = data.tempLF;
    doc["humLF"] = data.humLF;
    doc["tempLB"] = data.tempLB;
    doc["humLB"] = data.humLB;
    doc["waterPct"] = data.waterLevelPct;
    doc["waterTemp"] = data.waterTemp;
    doc["pH"] = data.pH;
    doc["tds"] = data.tds;
    doc["fanLF"] = data.fanLF_on;
    doc["fanLB"] = data.fanLB_on;
    doc["lightLF"] = data.lightLF_on;
    doc["lightLB"] = data.lightLB_on;

    char payload[512];
    serializeJson(doc, payload, sizeof(payload));

    return publish(TOPIC_PUBLISH, payload);
}

bool MqttManager::publish(const char* topic, const char* payload) {
    if (xSemaphoreTake(_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
        ESP_LOGW(TAG, "Mutex timeout, skipping publish to '%s'.", topic);
        return false;
    }

    bool ok = false;
    if (!_mqttClient.connected()) {
        ESP_LOGW(TAG, "Not connected, skipping publish to '%s'.", topic);
    } else {
        ok = _mqttClient.publish(topic, payload);
        if (ok) {
            ESP_LOGI(TAG, "Published to '%s': %s", topic, payload);
        } else {
            ESP_LOGW(TAG, "Publish to '%s' failed. State: %d", topic, _mqttClient.state());
        }
    }

    xSemaphoreGive(_mutex);
    return ok;
}

void MqttManager::maintain() {
    if (xSemaphoreTake(_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
        ESP_LOGW(TAG, "Mutex timeout in maintain(), skipping this cycle.");
        return;
    }

    if (!_mqttClient.connected()) {
        reconnect();
    }
    _mqttClient.loop();

    xSemaphoreGive(_mutex);
}

bool MqttManager::isConnected()  {
    return _mqttClient.connected();
}

int MqttManager::getState() {      
    return _mqttClient.state();
}

bool MqttManager::reconnect() {
    // NOTE: caller (maintain()) already holds _mutex when this runs.
    if (_mqttClient.connected()) return true;

    ESP_LOGI(TAG, "Connecting to %s:%d as %s...", _broker, _port, _clientId);
    
    if (_mqttClient.connect(_clientId)) {
        ESP_LOGI(TAG, "Connected!");
        _mqttClient.subscribe(TOPIC_SUBSCRIBE);
        return true;
    }

    int state = _mqttClient.state();
    ESP_LOGW(TAG, "Failed. State: %d", state);
    return false;
}

void MqttManager::mqttCallback(char* topic, byte* payload, unsigned int length) {
    ESP_LOGI(TAG, "Message received on %s", topic);
}*/ // This is the previous content of the file esp32_firmware/lgs_coordinator/main/MqttManager.cpp, which has been commented out.at 5:32 pm sept 11.

#include "MqttManager.h"
#include "Config.h"
#include "esp_log.h"
#include <ArduinoJson.h>
#include <Arduino.h>

static const char* TAG = "MQTT_MGR";

MqttManager::CommandCallback MqttManager::_commandCallback = nullptr;

MqttManager& MqttManager::instance() {
    static MqttManager inst;
    return inst;
}

void MqttManager::begin(const char* broker, uint16_t port, const char* clientId) {
    _broker = broker;
    _port = port;
    _clientId = clientId;
    
    _mqttClient.setClient(_wifiClient);
    _mqttClient.setServer(_broker, _port);
    _mqttClient.setCallback(mqttCallback);
    _mqttClient.setSocketTimeout(30);
    _mqttClient.setKeepAlive(60);
    
    ESP_LOGI(TAG, "Configured broker: %s:%d", _broker, _port);
}

void MqttManager::setCommandCallback(CommandCallback cb) {
    _commandCallback = cb;
}

bool MqttManager::publishSensorData(const SensorData& data) {
    JsonDocument doc;
    doc["unit"] = 1;
    doc["tempLF"] = data.tempLF;
    doc["humLF"] = data.humLF;
    doc["tempLB"] = data.tempLB;
    doc["humLB"] = data.humLB;
    doc["waterPct"] = data.waterLevelPct;
    doc["waterTemp"] = data.waterTemp;
    doc["pH"] = data.pH;
    doc["tds"] = data.tds;
    doc["fanLF"] = data.fanLF_on;
    doc["fanLB"] = data.fanLB_on;
    doc["lightLF"] = data.lightLF_on;
    doc["lightLB"] = data.lightLB_on;

    char payload[512];
    serializeJson(doc, payload, sizeof(payload));

    return publish(TOPIC_PUBLISH, payload);
}

bool MqttManager::publish(const char* topic, const char* payload) {
    if (xSemaphoreTake(_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
        ESP_LOGW(TAG, "Mutex timeout, skipping publish to '%s'.", topic);
        return false;
    }

    bool ok = false;
    if (!_mqttClient.connected()) {
        ESP_LOGW(TAG, "Not connected, skipping publish to '%s'.", topic);
    } else {
        ok = _mqttClient.publish(topic, payload);
        if (ok) {
            ESP_LOGI(TAG, "Published to '%s': %s", topic, payload);
        } else {
            ESP_LOGW(TAG, "Publish to '%s' failed. State: %d", topic, _mqttClient.state());
        }
    }

    xSemaphoreGive(_mutex);
    return ok;
}

void MqttManager::maintain() {
    if (xSemaphoreTake(_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
        ESP_LOGW(TAG, "Mutex timeout in maintain(), skipping this cycle.");
        return;
    }

    if (!_mqttClient.connected()) {
        reconnect();
    }
    _mqttClient.loop();

    xSemaphoreGive(_mutex);
}

bool MqttManager::isConnected()  {
    return _mqttClient.connected();
}

int MqttManager::getState() {      
    return _mqttClient.state();
}

bool MqttManager::reconnect() {
    // NOTE: caller (maintain()) already holds _mutex when this runs.
    if (_mqttClient.connected()) return true;

    ESP_LOGI(TAG, "Connecting to %s:%d as %s...", _broker, _port, _clientId);
    
    if (_mqttClient.connect(_clientId)) {
        ESP_LOGI(TAG, "Connected!");
        _mqttClient.subscribe(TOPIC_SUBSCRIBE);
        return true;
    }

    int state = _mqttClient.state();
    ESP_LOGW(TAG, "Failed. State: %d", state);
    return false;
}

void MqttManager::mqttCallback(char* topic, byte* payload, unsigned int length) {
    ESP_LOGI(TAG, "Message received on %s", topic);
    // IMPORTANT: this runs synchronously inside _mqttClient.loop(), which
    // itself runs inside maintain() while _mutex is HELD. The registered
    // callback must NOT call publish()/maintain() directly here - it must
    // only set a flag/queue for the calling task to act on afterward,
    // once maintain() has returned and released the mutex.
    if (_commandCallback) {
        _commandCallback(topic, payload, length);
    }
}