/*#ifndef MQTT_MANAGER_H
#define MQTT_MANAGER_H

#include <WiFi.h>
#include <PubSubClient.h>
#include "MessageTypes.h"
#include "Config.h"

class MqttManager {
public:
    static MqttManager& instance();

    void begin(const char* broker, uint16_t port, const char* clientId);
    bool publishSensorData(const SensorData& data);
    bool isConnected() ;
    int getState() ;      // <-- ADD THIS METHOD 
    void maintain();  //bool isConnected();

private:
    static void mqttCallback(char* topic, byte* payload, unsigned int length);
    MqttManager() : _mqttClient(_wifiClient) {}
    MqttManager(const MqttManager&) = delete;
    MqttManager& operator=(const MqttManager&) = delete;

    bool reconnect();

    WiFiClient   _wifiClient;
    PubSubClient _mqttClient;
    const char* _broker = nullptr;
    uint16_t    _port = 1883;
    const char* _clientId = nullptr;
};

#endif // MQTT_MANAGER_H */  // this is the previous content of the file esp32_firmware/lgs_coordinator/main/MqttManager.h, which has been commented out.at 2.31 pm sept 10.

//

/*#ifndef MQTT_MANAGER_H
#define MQTT_MANAGER_H
#include <WiFi.h>
#include <PubSubClient.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "MessageTypes.h"
#include "Config.h"
class MqttManager {
public:
    static MqttManager& instance();
    void begin(const char* broker, uint16_t port, const char* clientId);
    bool publishSensorData(const SensorData& data);
    bool publish(const char* topic, const char* payload);  // NEW: generic publish
    bool isConnected() ;
    int getState() ;      // <-- ADD THIS METHOD 
    void maintain();  //bool isConnected();
private:
    static void mqttCallback(char* topic, byte* payload, unsigned int length);
    MqttManager() : _mqttClient(_wifiClient) { _mutex = xSemaphoreCreateMutex(); }
    MqttManager(const MqttManager&) = delete;
    MqttManager& operator=(const MqttManager&) = delete;
    bool reconnect();
    WiFiClient   _wifiClient;
    PubSubClient _mqttClient;
    const char* _broker = nullptr;
    uint16_t    _port = 1883;
    const char* _clientId = nullptr;
    SemaphoreHandle_t _mutex = nullptr;  // NEW: guards _mqttClient across tasks
};
#endif // MQTT_MANAGER_H */  // this is the previous content of the file esp32_firmware/lgs_coordinator/main/MqttManager.h, which has been commented out.at 5:29 pm sept 11.

#ifndef MQTT_MANAGER_H
#define MQTT_MANAGER_H
#include <WiFi.h>
#include <PubSubClient.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "MessageTypes.h"
#include "Config.h"
class MqttManager {
public:
    using CommandCallback = void(*)(const char* topic, const uint8_t* payload, unsigned int length);

    static MqttManager& instance();
    void begin(const char* broker, uint16_t port, const char* clientId);
    bool publishSensorData(const SensorData& data);
    bool publish(const char* topic, const char* payload);  // generic publish
    void setCommandCallback(CommandCallback cb);            // NEW: Stage 5
    bool isConnected() ;
    int getState() ;      // <-- ADD THIS METHOD 
    void maintain();  //bool isConnected();
private:
    static void mqttCallback(char* topic, byte* payload, unsigned int length);
    MqttManager() : _mqttClient(_wifiClient) { _mutex = xSemaphoreCreateMutex(); }
    MqttManager(const MqttManager&) = delete;
    MqttManager& operator=(const MqttManager&) = delete;
    bool reconnect();
    WiFiClient   _wifiClient;
    PubSubClient _mqttClient;
    const char* _broker = nullptr;
    uint16_t    _port = 1883;
    const char* _clientId = nullptr;
    SemaphoreHandle_t _mutex = nullptr;
    static CommandCallback _commandCallback;  // NEW: Stage 5
};
#endif // MQTT_MANAGER_H