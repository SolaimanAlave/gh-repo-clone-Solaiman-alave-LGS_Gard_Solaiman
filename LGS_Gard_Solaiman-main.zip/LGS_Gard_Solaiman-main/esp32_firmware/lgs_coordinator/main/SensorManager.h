#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include "MessageTypes.h"

class SensorManager {
public:
    void begin();
    void startTasks();
    SensorData getLatestData();
    SensorDataPack& getDataPack() { return _dataPack; }

private:
    SensorDataPack _dataPack;

    static void taskReadSensorsWrapper(void* pvParameters);
    static void taskControlRelaysWrapper(void* pvParameters);

    void taskReadSensors();
    void taskControlRelays();
};

#endif // SENSOR_MANAGER_H