#ifndef ESP_WIFI_MANAGER_H
#define ESP_WIFI_MANAGER_H

#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT      BIT1

class ESPWiFiManager {
public:
    ESPWiFiManager();
    bool connect(const char* ssid, const char* password, uint32_t timeoutMs = 30000);
    bool isConnected();
    void maintain();
    esp_ip4_addr_t getIP();

private:
    static void event_handler(void* arg, esp_event_base_t event_base,
                              int32_t event_id, void* event_data);
    
    bool _connected;
    esp_ip4_addr_t _ip;
    EventGroupHandle_t _wifi_event_group;
    const char* _ssid;
    const char* _password;
    uint32_t _timeoutMs;
};

#endif