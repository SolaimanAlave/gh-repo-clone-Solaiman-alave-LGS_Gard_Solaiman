#ifndef CONFIG_H
#define CONFIG_H

// ── WiFi ──────────────────────────────────────────────────────────────────────
#define WIFI_SSID       "YOUR WIFI SSID"        //
#define WIFI_PASSWORD   "YOUR WIFI PASSWORD" // 

// ── MQTT ──────────────────────────────────────────────────────────────────────
#define MQTT_BROKER     "0.0.0.0"        // CHANGE TO YOUR MAC'S IP ADDRESS
#define MQTT_PORT       0000
#define MQTT_CLIENT_ID  "LGS_Coordinator_1"
#define TOPIC_PUBLISH   "GardenerSensorData"
#define TOPIC_SUBSCRIBE "GardenerCommand"
#define TOPIC_ROLE      "GardenerDeviceRole"      // Stage 2 role announcement
#define TOPIC_HEARTBEAT "GardenerHeartbeat"       // NEW: Stage 3 periodic heartbeat

// ── Zigbee ────────────────────────────────────────────────────────────────────
#define ZIGBEE_CHANNEL          15
#define MAX_CHILDREN            20
#define PERMIT_JOIN_DURATION    0xFF

// ── DHT Sensor Pins ───────────────────────────────────────────────────────────
#define DHT_LF_PIN      23
#define DHT_LB_PIN      4
#define DHT_TYPE        DHT22

// ── Water Level ───────────────────────────────────────────────────────────────
#define WATER_LEVEL_PIN 6

// ── Relay Pins ────────────────────────────────────────────────────────────────
#define RELAY_LF_LIGHT  5
#define RELAY_LF_FAN    7
#define RELAY_LB_LIGHT  8
#define RELAY_LB_FAN    9

// ── Thresholds ────────────────────────────────────────────────────────────────
#define TEMP_HIGH_THRESHOLD     30.0f
#define WATER_LOW_THRESHOLD     20

// ── FreeRTOS Task Config ──────────────────────────────────────────────────────
#define TASK_STACK_SENSOR       4096
#define TASK_STACK_RELAY        4096
#define TASK_STACK_MQTT         8192
#define TASK_PRIORITY_SENSOR    1
#define TASK_PRIORITY_RELAY     1
#define TASK_PRIORITY_MQTT      2

#define SENSOR_READ_INTERVAL_MS     10000
#define RELAY_CHECK_INTERVAL_MS     10000
#define MQTT_PUBLISH_INTERVAL_MS    15000
#define HEARTBEAT_INTERVAL_MS       10000   // NEW: Stage 3 heartbeat cadence

#endif // CONFIG_H