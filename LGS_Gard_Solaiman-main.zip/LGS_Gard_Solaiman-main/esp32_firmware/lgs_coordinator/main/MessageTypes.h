#ifndef MESSAGE_TYPES_H
#define MESSAGE_TYPES_H

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

struct SensorData {
    float tempLF, humLF;
    float tempLB, humLB;
    int   waterLevelPct;
    float waterTemp; //new added
    float pH; // new added
    float tds; // new added
    bool  fanLF_on;
    bool  fanLB_on;
    bool  lightLF_on;
    bool  lightLB_on;
};

struct SensorDataPack {
    SensorData       data;
    SemaphoreHandle_t mutex;
};

#endif // MESSAGE_TYPES_H