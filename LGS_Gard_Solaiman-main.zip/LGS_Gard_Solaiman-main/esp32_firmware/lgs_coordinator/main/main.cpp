/* #include <Arduino.h>
#include "esp_log.h"
#include "esp_mac.h"            // for esp_read_mac() - unique chip MAC
#include "Config.h"
#include "MessageTypes.h"
#include "esp_wifi_manager.h"   // ESP-IDF native WiFi
#include "MqttManager.h"
#include "SensorManager.h"
#include "ZigbeeCoordinator.h"
#include "nvs_flash.h"
#include "esp_coexist.h"
#include "esp_wifi.h"           // for esp_wifi_sta_get_ap_info (RSSI, optional)

static const char* TAG = "MAIN";

static ESPWiFiManager wifiManager;
static SensorManager sensorManager;

// --- Unique Device ID (Stage 1: distinguish Device A/B/C) ---
// Built from the chip's factory-programmed MAC address, so it's guaranteed
// unique per physical board and stable across reboots/reflashes.
static char deviceId[32];

static void generateDeviceId() {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    // Use the last 3 bytes of the MAC (6 hex chars) - plenty unique for a
    // small fleet, and short enough to be a clean MQTT client ID / topic segment.
    snprintf(deviceId, sizeof(deviceId), "LGS_C5_%02X%02X%02X",
              mac[3], mac[4], mac[5]);
}

// --- LED test (Stage 1: role indicator, wired active-low on GPIO2) ---
// Wiring: 3V3 -> 220R -> LED(long leg/anode) -> LED(short leg/cathode) -> GPIO2
// Active-low: LED lights when GPIO2 is driven LOW (it sinks current).
#define STATUS_LED_PIN 2

static void taskBlinkLed(void *pvParameters) {
    pinMode(STATUS_LED_PIN, OUTPUT);
    for (;;) {
        digitalWrite(STATUS_LED_PIN, LOW);   // LED ON (active-low)
        vTaskDelay(pdMS_TO_TICKS(500));
        digitalWrite(STATUS_LED_PIN, HIGH);  // LED OFF
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// Helper: print the current IP without touching Arduino's WiFi object.
static void logCurrentIP() {
    esp_ip4_addr_t ip = wifiManager.getIP();
    ESP_LOGI(TAG, "[WiFi] IP: " IPSTR, IP2STR(&ip));
}

// Optional: RSSI via native esp_wifi call instead of Arduino's WiFi.RSSI().
static void logRSSI() {
    wifi_ap_record_t ap_info;
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
        ESP_LOGI(TAG, "[WiFi] RSSI: %d dBm", ap_info.rssi);
    }
}

static void taskPublishMqtt(void *pvParameters) {
    SensorManager *sensors = static_cast<SensorManager *>(pvParameters);
    MqttManager &mqtt = MqttManager::instance();
    TickType_t lastPublish = xTaskGetTickCount();
    bool wasConnected = false;

    for (;;) {
        mqtt.maintain();
        wifiManager.maintain();

        bool nowConnected = mqtt.isConnected();
        if (nowConnected && !wasConnected) {
            ESP_LOGI(TAG, "[MQTT] Connected! (background reconnect)");
        }
        wasConnected = nowConnected;

        if (xTaskGetTickCount() - lastPublish >= pdMS_TO_TICKS(MQTT_PUBLISH_INTERVAL_MS)) {
            SensorData data = sensors->getLatestData();
            mqtt.publishSensorData(data);
            lastPublish = xTaskGetTickCount();
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

extern "C" void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    initArduino();
    Serial.begin(115200);  // kept in case other Arduino libraries expect it

    // Generate this device's unique ID from its MAC address, right at boot,
    // before anything else needs it (MQTT client ID, future Postgres writes).
    generateDeviceId();
    ESP_LOGI(TAG, "[Device] Unique ID: %s", deviceId);

    // Start LED blink test immediately, independent of WiFi/MQTT/Zigbee,
    // so we can confirm wiring/GPIO works before building role-indicator logic.
    xTaskCreate(taskBlinkLed, "BlinkLed", 2048, NULL, 1, NULL);
    ESP_LOGI(TAG, "[LED] Blink task started on GPIO %d (active-low)", STATUS_LED_PIN);

    esp_err_t err = esp_coex_wifi_i154_enable();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "[Coex] enable failed: %s", esp_err_to_name(err));
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
    vTaskDelay(pdMS_TO_TICKS(2000));  // Give system time to stabilize

    // 1. WiFi - connect() already blocks internally up to timeoutMs
    //    and returns true/false.
    ESP_LOGI(TAG, "[WiFi] Connecting...");
    bool wifiConnected = wifiManager.connect(WIFI_SSID, WIFI_PASSWORD, 30000);

    if (wifiConnected) {
        ESP_LOGI(TAG, "[WiFi] Connected!");
        logCurrentIP();
        logRSSI();
    } else {
        ESP_LOGW(TAG, "[WiFi] Connection failed!");
        // Continue anyway - MQTT will handle connection failure
    }

    // 2. MQTT - Connect only if WiFi is connected
    if (wifiConnected) {
        ESP_LOGI(TAG, "[MQTT] Connecting to broker %s:%d as %s ...", MQTT_BROKER, MQTT_PORT, deviceId);
        // Use the MAC-derived device ID as the MQTT client ID, instead of the
        // old hardcoded MQTT_CLIENT_ID - this is what makes each physical
        // device distinguishable once multiple boards are on the network.
        MqttManager::instance().begin(MQTT_BROKER, MQTT_PORT, deviceId);

        // Wait for MQTT connection
        int mqtt_retries = 0;
        while (!MqttManager::instance().isConnected() && mqtt_retries < 30) {
            MqttManager::instance().maintain();
            vTaskDelay(pdMS_TO_TICKS(200));
            mqtt_retries++;
        }

        if (MqttManager::instance().isConnected()) {
            ESP_LOGI(TAG, "[MQTT] Connected!");
        } else {
            ESP_LOGW(TAG, "[MQTT] Connection failed! State: %d", MqttManager::instance().getState());
            // MQTT will continue trying in the publish task via maintain()
        }
    } else {
        ESP_LOGW(TAG, "[MQTT] Skipping - WiFi not connected");
    }

    // 3. Sensors + relay tasks
    sensorManager.begin();
    sensorManager.startTasks();

    vTaskDelay(pdMS_TO_TICKS(3000));

    // 4. MQTT publish task (will maintain MQTT connection)
    xTaskCreatePinnedToCore(taskPublishMqtt, "MqttPublish", TASK_STACK_MQTT,
                            &sensorManager, TASK_PRIORITY_MQTT, NULL, 0);

    // 5. Zigbee Coordinator
    vTaskDelay(pdMS_TO_TICKS(6000));
    xTaskCreate(esp_zb_task, "zigbee_task", 8192, NULL, 5, NULL);
    xTaskCreate(button_task, "button_task", 4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "[Main] All tasks started. Device ID: %s", deviceId);
}

void setup() {}
void loop() {} */ // This is the previous content of the file esp32_firmware/lgs_coordinator/main/main.cpp, which has been commented out.at 2.31 pm sept 10.

/*#include <Arduino.h>
#include "esp_log.h"
#include "esp_mac.h"            // for esp_read_mac() - unique chip MAC
#include "esp_zigbee_core.h"    // for esp_zb_get_pan_id/current_channel/short_address
#include "Config.h"
#include "MessageTypes.h"
#include "esp_wifi_manager.h"   // ESP-IDF native WiFi
#include "MqttManager.h"
#include "SensorManager.h"
#include "ZigbeeCoordinator.h"
#include "nvs_flash.h"
#include "esp_coexist.h"
#include "esp_wifi.h"           // for esp_wifi_sta_get_ap_info (RSSI, optional)
#include <ArduinoJson.h>

static const char* TAG = "MAIN";

static ESPWiFiManager wifiManager;
static SensorManager sensorManager;

// --- Unique Device ID (Stage 1: distinguish Device A/B/C) ---
static char deviceId[32];

static void generateDeviceId() {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(deviceId, sizeof(deviceId), "LGS_C5_%02X%02X%02X",
              mac[3], mac[4], mac[5]);
}

// --- LED test (Stage 1: role indicator, wired active-low on GPIO2) ---
#define STATUS_LED_PIN 2

static void taskBlinkLed(void *pvParameters) {
    pinMode(STATUS_LED_PIN, OUTPUT);
    for (;;) {
        digitalWrite(STATUS_LED_PIN, LOW);   // LED ON (active-low)
        vTaskDelay(pdMS_TO_TICKS(500));
        digitalWrite(STATUS_LED_PIN, HIGH);  // LED OFF
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// --- Stage 2: Role announcement ---
// Publishes { device_id, role, pan_id, channel, short_addr } once, after
// giving the Zigbee network time to finish forming. One-shot task that
// deletes itself when done.
static void taskAnnounceRole(void *pvParameters) {
    // Wait for the Zigbee network to form. main_app already waits 6s before
    // starting the Zigbee task, and formation itself takes well under a
    // second based on observed logs - 5s here is a safe margin.
    vTaskDelay(pdMS_TO_TICKS(5000));

    uint16_t panId = esp_zb_get_pan_id();
    uint8_t channel = esp_zb_get_current_channel();
    uint16_t shortAddr = esp_zb_get_short_address();

    char panIdStr[8];
    snprintf(panIdStr, sizeof(panIdStr), "0x%04x", panId);
    char shortAddrStr[8];
    snprintf(shortAddrStr, sizeof(shortAddrStr), "0x%04x", shortAddr);

    JsonDocument doc;
    doc["device_id"] = deviceId;
    doc["role"] = "coordinator";
    doc["pan_id"] = panIdStr;
    doc["channel"] = channel;
    doc["short_addr"] = shortAddrStr;

    char payload[256];
    serializeJson(doc, payload, sizeof(payload));

    bool ok = MqttManager::instance().publish(TOPIC_ROLE, payload);
    if (ok) {
        ESP_LOGI(TAG, "[Role] Announced as coordinator: %s", payload);
    } else {
        ESP_LOGW(TAG, "[Role] Failed to announce role.");
    }

    vTaskDelete(NULL);  // one-shot task, done after this
}

// Helper: print the current IP without touching Arduino's WiFi object.
static void logCurrentIP() {
    esp_ip4_addr_t ip = wifiManager.getIP();
    ESP_LOGI(TAG, "[WiFi] IP: " IPSTR, IP2STR(&ip));
}

static void logRSSI() {
    wifi_ap_record_t ap_info;
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
        ESP_LOGI(TAG, "[WiFi] RSSI: %d dBm", ap_info.rssi);
    }
}

static void taskPublishMqtt(void *pvParameters) {
    SensorManager *sensors = static_cast<SensorManager *>(pvParameters);
    MqttManager &mqtt = MqttManager::instance();
    TickType_t lastPublish = xTaskGetTickCount();
    bool wasConnected = false;

    for (;;) {
        mqtt.maintain();
        wifiManager.maintain();

        bool nowConnected = mqtt.isConnected();
        if (nowConnected && !wasConnected) {
            ESP_LOGI(TAG, "[MQTT] Connected! (background reconnect)");
        }
        wasConnected = nowConnected;

        if (xTaskGetTickCount() - lastPublish >= pdMS_TO_TICKS(MQTT_PUBLISH_INTERVAL_MS)) {
            SensorData data = sensors->getLatestData();
            mqtt.publishSensorData(data);
            lastPublish = xTaskGetTickCount();
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

extern "C" void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    initArduino();
    Serial.begin(115200);

    generateDeviceId();
    ESP_LOGI(TAG, "[Device] Unique ID: %s", deviceId);

    xTaskCreate(taskBlinkLed, "BlinkLed", 2048, NULL, 1, NULL);
    ESP_LOGI(TAG, "[LED] Blink task started on GPIO %d (active-low)", STATUS_LED_PIN);

    esp_err_t err = esp_coex_wifi_i154_enable();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "[Coex] enable failed: %s", esp_err_to_name(err));
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
    vTaskDelay(pdMS_TO_TICKS(2000));

    ESP_LOGI(TAG, "[WiFi] Connecting...");
    bool wifiConnected = wifiManager.connect(WIFI_SSID, WIFI_PASSWORD, 30000);

    if (wifiConnected) {
        ESP_LOGI(TAG, "[WiFi] Connected!");
        logCurrentIP();
        logRSSI();
    } else {
        ESP_LOGW(TAG, "[WiFi] Connection failed!");
    }

    if (wifiConnected) {
        ESP_LOGI(TAG, "[MQTT] Connecting to broker %s:%d as %s ...", MQTT_BROKER, MQTT_PORT, deviceId);
        MqttManager::instance().begin(MQTT_BROKER, MQTT_PORT, deviceId);

        int mqtt_retries = 0;
        while (!MqttManager::instance().isConnected() && mqtt_retries < 30) {
            MqttManager::instance().maintain();
            vTaskDelay(pdMS_TO_TICKS(200));
            mqtt_retries++;
        }

        if (MqttManager::instance().isConnected()) {
            ESP_LOGI(TAG, "[MQTT] Connected!");
        } else {
            ESP_LOGW(TAG, "[MQTT] Connection failed! State: %d", MqttManager::instance().getState());
        }
    } else {
        ESP_LOGW(TAG, "[MQTT] Skipping - WiFi not connected");
    }

    sensorManager.begin();
    sensorManager.startTasks();

    vTaskDelay(pdMS_TO_TICKS(3000));

    xTaskCreatePinnedToCore(taskPublishMqtt, "MqttPublish", TASK_STACK_MQTT,
                            &sensorManager, TASK_PRIORITY_MQTT, NULL, 0);

    vTaskDelay(pdMS_TO_TICKS(6000));
    xTaskCreate(esp_zb_task, "zigbee_task", 8192, NULL, 5, NULL);
    xTaskCreate(button_task, "button_task", 4096, NULL, 5, NULL);

    // Stage 2: announce coordinator role once Zigbee network has formed.
    xTaskCreate(taskAnnounceRole, "AnnounceRole", 4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "[Main] All tasks started. Device ID: %s", deviceId);
}

void setup() {}
void loop() {} */ // This is the previous content of the file esp32_firmware/lgs_coordinator/main/main.cpp, which has been commented out.at 4:58 pm pm sept 10.

/*#include <Arduino.h>
#include "esp_log.h"
#include "esp_mac.h"            // for esp_read_mac() - unique chip MAC
#include "esp_zigbee_core.h"    // for esp_zb_get_pan_id/current_channel/short_address
#include "Config.h"
#include "MessageTypes.h"
#include "esp_wifi_manager.h"   // ESP-IDF native WiFi
#include "MqttManager.h"
#include "SensorManager.h"
#include "ZigbeeCoordinator.h"
#include "nvs_flash.h"
#include "esp_coexist.h"
#include "esp_wifi.h"           // for esp_wifi_sta_get_ap_info (RSSI, optional)
#include <ArduinoJson.h>

static const char* TAG = "MAIN";

static ESPWiFiManager wifiManager;
static SensorManager sensorManager;

// --- Unique Device ID (Stage 1: distinguish Device A/B/C) ---
static char deviceId[32];

static void generateDeviceId() {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(deviceId, sizeof(deviceId), "LGS_C5_%02X%02X%02X",
              mac[3], mac[4], mac[5]);
}

// --- LED test (Stage 1: role indicator, wired active-low on GPIO2) ---
#define STATUS_LED_PIN 2

static void taskBlinkLed(void *pvParameters) {
    pinMode(STATUS_LED_PIN, OUTPUT);
    for (;;) {
        digitalWrite(STATUS_LED_PIN, LOW);   // LED ON (active-low)
        vTaskDelay(pdMS_TO_TICKS(500));
        digitalWrite(STATUS_LED_PIN, HIGH);  // LED OFF
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// --- Stage 2: Role announcement ---
static void taskAnnounceRole(void *pvParameters) {
    vTaskDelay(pdMS_TO_TICKS(5000));

    uint16_t panId = esp_zb_get_pan_id();
    uint8_t channel = esp_zb_get_current_channel();
    uint16_t shortAddr = esp_zb_get_short_address();

    char panIdStr[8];
    snprintf(panIdStr, sizeof(panIdStr), "0x%04x", panId);
    char shortAddrStr[8];
    snprintf(shortAddrStr, sizeof(shortAddrStr), "0x%04x", shortAddr);

    JsonDocument doc;
    doc["device_id"] = deviceId;
    doc["role"] = "coordinator";
    doc["pan_id"] = panIdStr;
    doc["channel"] = channel;
    doc["short_addr"] = shortAddrStr;

    char payload[256];
    serializeJson(doc, payload, sizeof(payload));

    bool ok = MqttManager::instance().publish(TOPIC_ROLE, payload);
    if (ok) {
        ESP_LOGI(TAG, "[Role] Announced as coordinator: %s", payload);
    } else {
        ESP_LOGW(TAG, "[Role] Failed to announce role.");
    }

    vTaskDelete(NULL);  // one-shot task, done after this
}

// Helper: print the current IP without touching Arduino's WiFi object.
static void logCurrentIP() {
    esp_ip4_addr_t ip = wifiManager.getIP();
    ESP_LOGI(TAG, "[WiFi] IP: " IPSTR, IP2STR(&ip));
}

static void logRSSI() {
    wifi_ap_record_t ap_info;
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
        ESP_LOGI(TAG, "[WiFi] RSSI: %d dBm", ap_info.rssi);
    }
}

// --- Stage 3: Heartbeat publish ---
// Lightweight, frequent "I'm alive" message the orchestrator watches for.
// Separate from the (larger, slower) sensor data publish.
static void publishHeartbeat() {
    JsonDocument doc;
    doc["device_id"] = deviceId;
    doc["timestamp"] = millis();

    char payload[128];
    serializeJson(doc, payload, sizeof(payload));

    MqttManager::instance().publish(TOPIC_HEARTBEAT, payload);
}

static void taskPublishMqtt(void *pvParameters) {
    SensorManager *sensors = static_cast<SensorManager *>(pvParameters);
    MqttManager &mqtt = MqttManager::instance();
    TickType_t lastPublish = xTaskGetTickCount();
    TickType_t lastHeartbeat = xTaskGetTickCount();
    bool wasConnected = false;

    for (;;) {
        mqtt.maintain();
        wifiManager.maintain();

        bool nowConnected = mqtt.isConnected();
        if (nowConnected && !wasConnected) {
            ESP_LOGI(TAG, "[MQTT] Connected! (background reconnect)");
        }
        wasConnected = nowConnected;

        if (xTaskGetTickCount() - lastHeartbeat >= pdMS_TO_TICKS(HEARTBEAT_INTERVAL_MS)) {
            publishHeartbeat();
            lastHeartbeat = xTaskGetTickCount();
        }

        if (xTaskGetTickCount() - lastPublish >= pdMS_TO_TICKS(MQTT_PUBLISH_INTERVAL_MS)) {
            SensorData data = sensors->getLatestData();
            mqtt.publishSensorData(data);
            lastPublish = xTaskGetTickCount();
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

extern "C" void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    initArduino();
    Serial.begin(115200);

    generateDeviceId();
    ESP_LOGI(TAG, "[Device] Unique ID: %s", deviceId);

    xTaskCreate(taskBlinkLed, "BlinkLed", 2048, NULL, 1, NULL);
    ESP_LOGI(TAG, "[LED] Blink task started on GPIO %d (active-low)", STATUS_LED_PIN);

    esp_err_t err = esp_coex_wifi_i154_enable();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "[Coex] enable failed: %s", esp_err_to_name(err));
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
    vTaskDelay(pdMS_TO_TICKS(2000));

    ESP_LOGI(TAG, "[WiFi] Connecting...");
    bool wifiConnected = wifiManager.connect(WIFI_SSID, WIFI_PASSWORD, 30000);

    if (wifiConnected) {
        ESP_LOGI(TAG, "[WiFi] Connected!");
        logCurrentIP();
        logRSSI();
    } else {
        ESP_LOGW(TAG, "[WiFi] Connection failed!");
    }

    if (wifiConnected) {
        ESP_LOGI(TAG, "[MQTT] Connecting to broker %s:%d as %s ...", MQTT_BROKER, MQTT_PORT, deviceId);
        MqttManager::instance().begin(MQTT_BROKER, MQTT_PORT, deviceId);

        int mqtt_retries = 0;
        while (!MqttManager::instance().isConnected() && mqtt_retries < 30) {
            MqttManager::instance().maintain();
            vTaskDelay(pdMS_TO_TICKS(200));
            mqtt_retries++;
        }

        if (MqttManager::instance().isConnected()) {
            ESP_LOGI(TAG, "[MQTT] Connected!");
        } else {
            ESP_LOGW(TAG, "[MQTT] Connection failed! State: %d", MqttManager::instance().getState());
        }
    } else {
        ESP_LOGW(TAG, "[MQTT] Skipping - WiFi not connected");
    }

    sensorManager.begin();
    sensorManager.startTasks();

    vTaskDelay(pdMS_TO_TICKS(3000));

    xTaskCreatePinnedToCore(taskPublishMqtt, "MqttPublish", TASK_STACK_MQTT,
                            &sensorManager, TASK_PRIORITY_MQTT, NULL, 0);

    vTaskDelay(pdMS_TO_TICKS(6000));
    xTaskCreate(esp_zb_task, "zigbee_task", 8192, NULL, 5, NULL);
    xTaskCreate(button_task, "button_task", 4096, NULL, 5, NULL);

    xTaskCreate(taskAnnounceRole, "AnnounceRole", 4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "[Main] All tasks started. Device ID: %s", deviceId);
}

void setup() {}
void loop() {} */ // This is the previous content of the file esp32_firmware/lgs_coordinator/main/main.cpp, which has been commented out.at 5:32 pm sept 11.

#include <Arduino.h>
#include "esp_log.h"
#include "esp_mac.h"            // for esp_read_mac() - unique chip MAC
#include "esp_zigbee_core.h"    // for esp_zb_get_pan_id/current_channel/short_address
#include "Config.h"
#include "MessageTypes.h"
#include "esp_wifi_manager.h"   // ESP-IDF native WiFi
#include "MqttManager.h"
#include "SensorManager.h"
#include "ZigbeeCoordinator.h"
#include "nvs_flash.h"
#include "esp_coexist.h"
#include "esp_wifi.h"           // for esp_wifi_sta_get_ap_info (RSSI, optional)
#include <ArduinoJson.h>
#include <string.h>

static const char* TAG = "MAIN";

static ESPWiFiManager wifiManager;
static SensorManager sensorManager;

// --- Unique Device ID (Stage 1: distinguish Device A/B/C) ---
static char deviceId[32];

static void generateDeviceId() {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(deviceId, sizeof(deviceId), "LGS_C5_%02X%02X%02X",
              mac[3], mac[4], mac[5]);
}

// --- LED test (Stage 1: role indicator, wired active-low on GPIO2) ---
#define STATUS_LED_PIN 2

static void taskBlinkLed(void *pvParameters) {
    pinMode(STATUS_LED_PIN, OUTPUT);
    for (;;) {
        digitalWrite(STATUS_LED_PIN, LOW);   // LED ON (active-low)
        vTaskDelay(pdMS_TO_TICKS(500));
        digitalWrite(STATUS_LED_PIN, HIGH);  // LED OFF
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// --- Stage 2/5: Role announcement ---
// Shared by the boot-time one-shot task AND by Stage 5's command-triggered
// re-announcement, so both paths publish an identical, correct payload.
static void announceRole(const char* role) {
    uint16_t panId = esp_zb_get_pan_id();
    uint8_t channel = esp_zb_get_current_channel();
    uint16_t shortAddr = esp_zb_get_short_address();

    char panIdStr[8];
    snprintf(panIdStr, sizeof(panIdStr), "0x%04x", panId);
    char shortAddrStr[8];
    snprintf(shortAddrStr, sizeof(shortAddrStr), "0x%04x", shortAddr);

    JsonDocument doc;
    doc["device_id"] = deviceId;
    doc["role"] = role;
    doc["pan_id"] = panIdStr;
    doc["channel"] = channel;
    doc["short_addr"] = shortAddrStr;

    char payload[256];
    serializeJson(doc, payload, sizeof(payload));

    bool ok = MqttManager::instance().publish(TOPIC_ROLE, payload);
    if (ok) {
        ESP_LOGI(TAG, "[Role] Announced as %s: %s", role, payload);
    } else {
        ESP_LOGW(TAG, "[Role] Failed to announce role.");
    }
}

static void taskAnnounceRole(void *pvParameters) {
    vTaskDelay(pdMS_TO_TICKS(5000));  // give Zigbee network time to form
    announceRole("coordinator");
    vTaskDelete(NULL);  // one-shot task, done after this
}

// --- Stage 5: Incoming command handling ---
// Command JSON: {"command":"promote_to_coordinator","target_device_id":"..."}
//
// IMPORTANT: this function runs inside MqttManager's mqttCallback, which
// itself runs inside _mqttClient.loop() while MqttManager's internal mutex
// is HELD. We must NOT call MqttManager::publish()/maintain() here directly
// - doing so would try to re-take the same mutex from the same call stack
// and time out. Instead we just set a flag; taskPublishMqtt acts on it
// after maintain() has returned and released the mutex.
static volatile bool g_pendingPromotion = false;

static void handleCommand(const char* topic, const uint8_t* payload, unsigned int length) {
    if (strcmp(topic, TOPIC_SUBSCRIBE) != 0) return;

    char buf[256];
    unsigned int len = length < sizeof(buf) - 1 ? length : sizeof(buf) - 1;
    memcpy(buf, payload, len);
    buf[len] = '\0';

    JsonDocument doc;
    if (deserializeJson(doc, buf) != DeserializationError::Ok) {
        ESP_LOGW(TAG, "[Command] Failed to parse: %s", buf);
        return;
    }

    const char* command = doc["command"] | "";
    const char* target = doc["target_device_id"] | "";

    if (strcmp(command, "promote_to_coordinator") == 0 && strcmp(target, deviceId) == 0) {
        ESP_LOGI(TAG, "[Command] Promotion command received for this device.");
        g_pendingPromotion = true;  // handled safely outside the MQTT callback
    }
}

// Helper: print the current IP without touching Arduino's WiFi object.
static void logCurrentIP() {
    esp_ip4_addr_t ip = wifiManager.getIP();
    ESP_LOGI(TAG, "[WiFi] IP: " IPSTR, IP2STR(&ip));
}

static void logRSSI() {
    wifi_ap_record_t ap_info;
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
        ESP_LOGI(TAG, "[WiFi] RSSI: %d dBm", ap_info.rssi);
    }
}

// --- Stage 3: Heartbeat publish ---
static void publishHeartbeat() {
    JsonDocument doc;
    doc["device_id"] = deviceId;
    doc["timestamp"] = millis();

    char payload[128];
    serializeJson(doc, payload, sizeof(payload));

    MqttManager::instance().publish(TOPIC_HEARTBEAT, payload);
}

static void taskPublishMqtt(void *pvParameters) {
    SensorManager *sensors = static_cast<SensorManager *>(pvParameters);
    MqttManager &mqtt = MqttManager::instance();
    TickType_t lastPublish = xTaskGetTickCount();
    TickType_t lastHeartbeat = xTaskGetTickCount();
    bool wasConnected = false;

    for (;;) {
        mqtt.maintain();  // mutex released by the time this returns
        wifiManager.maintain();

        // Stage 5: act on any promotion command received during maintain()'s
        // internal loop() call, now that the mutex is free again.
        if (g_pendingPromotion) {
            g_pendingPromotion = false;
            ESP_LOGI(TAG, "[Command] Re-announcing as coordinator.");
            announceRole("coordinator");
        }

        bool nowConnected = mqtt.isConnected();
        if (nowConnected && !wasConnected) {
            ESP_LOGI(TAG, "[MQTT] Connected! (background reconnect)");
        }
        wasConnected = nowConnected;

        if (xTaskGetTickCount() - lastHeartbeat >= pdMS_TO_TICKS(HEARTBEAT_INTERVAL_MS)) {
            publishHeartbeat();
            lastHeartbeat = xTaskGetTickCount();
        }

        if (xTaskGetTickCount() - lastPublish >= pdMS_TO_TICKS(MQTT_PUBLISH_INTERVAL_MS)) {
            SensorData data = sensors->getLatestData();
            mqtt.publishSensorData(data);
            lastPublish = xTaskGetTickCount();
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

extern "C" void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    initArduino();
    Serial.begin(115200);

    generateDeviceId();
    ESP_LOGI(TAG, "[Device] Unique ID: %s", deviceId);

    MqttManager::instance().setCommandCallback(handleCommand);

    xTaskCreate(taskBlinkLed, "BlinkLed", 2048, NULL, 1, NULL);
    ESP_LOGI(TAG, "[LED] Blink task started on GPIO %d (active-low)", STATUS_LED_PIN);

    esp_err_t err = esp_coex_wifi_i154_enable();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "[Coex] enable failed: %s", esp_err_to_name(err));
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
    vTaskDelay(pdMS_TO_TICKS(2000));

    ESP_LOGI(TAG, "[WiFi] Connecting...");
    bool wifiConnected = wifiManager.connect(WIFI_SSID, WIFI_PASSWORD, 30000);

    if (wifiConnected) {
        ESP_LOGI(TAG, "[WiFi] Connected!");
        logCurrentIP();
        logRSSI();
    } else {
        ESP_LOGW(TAG, "[WiFi] Connection failed!");
    }

    if (wifiConnected) {
        ESP_LOGI(TAG, "[MQTT] Connecting to broker %s:%d as %s ...", MQTT_BROKER, MQTT_PORT, deviceId);
        MqttManager::instance().begin(MQTT_BROKER, MQTT_PORT, deviceId);

        int mqtt_retries = 0;
        while (!MqttManager::instance().isConnected() && mqtt_retries < 30) {
            MqttManager::instance().maintain();
            vTaskDelay(pdMS_TO_TICKS(200));
            mqtt_retries++;
        }

        if (MqttManager::instance().isConnected()) {
            ESP_LOGI(TAG, "[MQTT] Connected!");
        } else {
            ESP_LOGW(TAG, "[MQTT] Connection failed! State: %d", MqttManager::instance().getState());
        }
    } else {
        ESP_LOGW(TAG, "[MQTT] Skipping - WiFi not connected");
    }

    sensorManager.begin();
    sensorManager.startTasks();

    vTaskDelay(pdMS_TO_TICKS(3000));

    xTaskCreatePinnedToCore(taskPublishMqtt, "MqttPublish", TASK_STACK_MQTT,
                            &sensorManager, TASK_PRIORITY_MQTT, NULL, 0);

    vTaskDelay(pdMS_TO_TICKS(6000));
    xTaskCreate(esp_zb_task, "zigbee_task", 8192, NULL, 5, NULL);
    xTaskCreate(button_task, "button_task", 4096, NULL, 5, NULL);

    xTaskCreate(taskAnnounceRole, "AnnounceRole", 4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "[Main] All tasks started. Device ID: %s", deviceId);
}

void setup() {}
void loop() {}