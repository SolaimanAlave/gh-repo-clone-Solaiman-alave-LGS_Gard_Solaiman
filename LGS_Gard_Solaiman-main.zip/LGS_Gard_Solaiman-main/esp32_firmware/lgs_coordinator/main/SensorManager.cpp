#include "SensorManager.h"
#include "Config.h"
#include <Arduino.h>
#include <DHT.h>

static DHT dhtLF(DHT_LF_PIN, DHT_TYPE);
static DHT dhtLB(DHT_LB_PIN, DHT_TYPE);

static void setRelay(int pin, bool on) {
    digitalWrite(pin, on ? LOW : HIGH);
}

static int waterLevelPercent(int raw) {
    raw = constrain(raw, 0, 4095);
    return map(raw, 0, 4095, 0, 100);
}

void SensorManager::begin() {
    pinMode(RELAY_LF_FAN, OUTPUT);
    pinMode(RELAY_LB_FAN, OUTPUT);
    pinMode(RELAY_LF_LIGHT, OUTPUT);
    pinMode(RELAY_LB_LIGHT, OUTPUT);
    dhtLF.begin();
    dhtLB.begin();
    _dataPack.mutex = xSemaphoreCreateMutex();
    Serial.println("[Sensors] Initialized.");
}

void SensorManager::startTasks() {
    xTaskCreatePinnedToCore(taskReadSensorsWrapper, "ReadSensors", TASK_STACK_SENSOR, this, TASK_PRIORITY_SENSOR, NULL, 0);
    xTaskCreatePinnedToCore(taskControlRelaysWrapper, "ControlRelays", TASK_STACK_RELAY, this, TASK_PRIORITY_RELAY, NULL, 0);
    Serial.println("[Sensors] Tasks started.");
}

SensorData SensorManager::getLatestData() {
    SensorData snapshot = {};
    if (xSemaphoreTake(_dataPack.mutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        snapshot = _dataPack.data;
        xSemaphoreGive(_dataPack.mutex);
    }
    return snapshot;
}

void SensorManager::taskReadSensorsWrapper(void* pvParameters) {
    static_cast<SensorManager*>(pvParameters)->taskReadSensors();
}

void SensorManager::taskControlRelaysWrapper(void* pvParameters) {
    static_cast<SensorManager*>(pvParameters)->taskControlRelays();
}

void SensorManager::taskReadSensors() {
    for (;;) {
        SensorData local = {};
        // Read DHT sensors
        local.tempLF = dhtLF.readTemperature();
        local.humLF = dhtLF.readHumidity();
        local.tempLB = dhtLB.readTemperature();
        local.humLB = dhtLB.readHumidity();
        // Read water level
        local.waterLevelPct = waterLevelPercent(analogRead(WATER_LEVEL_PIN));

        // DUMMY placeholder values (no hardware wired for these yet)
        local.waterTemp = 22.0f;
        local.pH = 6.5f;
        local.tds = 650.0f;

        if (xSemaphoreTake(_dataPack.mutex, pdMS_TO_TICKS(100)) == pdTRUE) {
            _dataPack.data = local;
            xSemaphoreGive(_dataPack.mutex);
        }
        Serial.printf("[Sensors] LF: %.1f°C %.1f%%  LB: %.1f°C %.1f%%\n",
            local.tempLF, local.humLF, local.tempLB, local.humLB);
        Serial.printf("[Sensors] Water: %d%%\n", local.waterLevelPct);
        vTaskDelay(pdMS_TO_TICKS(SENSOR_READ_INTERVAL_MS));
    }
}

void SensorManager::taskControlRelays() {
    for (;;) {
        SensorData local = getLatestData();
        // Fan control based on temperature
        local.fanLF_on = !isnan(local.tempLF) && local.tempLF > TEMP_HIGH_THRESHOLD;
        local.fanLB_on = !isnan(local.tempLB) && local.tempLB > TEMP_HIGH_THRESHOLD;
        setRelay(RELAY_LF_FAN, local.fanLF_on);
        setRelay(RELAY_LB_FAN, local.fanLB_on);
        // Light control (always on for testing)
        local.lightLF_on = true;
        local.lightLB_on = true;
        setRelay(RELAY_LF_LIGHT, local.lightLF_on);
        setRelay(RELAY_LB_LIGHT, local.lightLB_on);
        if (xSemaphoreTake(_dataPack.mutex, pdMS_TO_TICKS(100)) == pdTRUE) {
            _dataPack.data = local;
            xSemaphoreGive(_dataPack.mutex);
        }
        vTaskDelay(pdMS_TO_TICKS(RELAY_CHECK_INTERVAL_MS));
    }
}
