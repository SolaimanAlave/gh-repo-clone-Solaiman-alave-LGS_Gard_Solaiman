#ifndef ZIGBEE_COORDINATOR_H
#define ZIGBEE_COORDINATOR_H

#ifdef __cplusplus
extern "C" {
#endif

void zigbee_coordinator_init(void);
void esp_zb_task(void* pvParameters);
void button_task(void* pvParameters);

#ifdef __cplusplus
}
#endif

#endif // ZIGBEE_COORDINATOR_H
