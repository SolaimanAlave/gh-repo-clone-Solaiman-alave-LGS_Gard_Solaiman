#include "esp_wifi_manager.h"
#include "esp_log.h"
#include <cstring>

static const char* TAG = "ESP_WIFI";

ESPWiFiManager::ESPWiFiManager() : _connected(false) {
    _ip.addr = 0;
    _wifi_event_group = xEventGroupCreate();
}

void ESPWiFiManager::event_handler(void* arg, esp_event_base_t event_base,
                                   int32_t event_id, void* event_data) {
    ESPWiFiManager* mgr = (ESPWiFiManager*)arg;

    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        // NOTE: connect() is no longer triggered here. We call esp_wifi_connect()
        // explicitly in connect() after the band mode is locked, to avoid a race
        // between this event firing and the band-mode lock being applied.
        ESP_LOGI(TAG, "WiFi station started");
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_CONNECTED) {
        ESP_LOGI(TAG, "WiFi connected to AP");
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "WiFi disconnected, reconnecting...");
        mgr->_connected = false;
        xEventGroupClearBits(mgr->_wifi_event_group, WIFI_CONNECTED_BIT);
        esp_wifi_connect();
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        mgr->_ip = event->ip_info.ip;
        mgr->_connected = true;
        xEventGroupSetBits(mgr->_wifi_event_group, WIFI_CONNECTED_BIT);
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&mgr->_ip));
    }
}

bool ESPWiFiManager::connect(const char* ssid, const char* password, uint32_t timeoutMs) {
    _ssid = ssid;
    _password = password;
    _timeoutMs = timeoutMs;

    // Initialize TCP/IP stack
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // Create default WiFi station
    esp_netif_t* sta_netif = esp_netif_create_default_wifi_sta();
    assert(sta_netif);

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &event_handler,
                                                        this,
                                                        NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &event_handler,
                                                        this,
                                                        NULL));

    // Configure WiFi
    wifi_config_t wifi_config = {};
    memcpy(wifi_config.sta.ssid, ssid, strlen(ssid));
    memcpy(wifi_config.sta.password, password, strlen(password));
    wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    // --- Fix for ESP32-C5 band-switch crash ---
    // esp_wifi_set_band_mode() requires WiFi to already be started, so it must
    // come after esp_wifi_start(). Locking to 5G-only prevents the driver from
    // ever falling back to 2.4GHz channel 1 on a failed connect attempt, which
    // is what triggered the regdomain-reprocessing crash during reconnects.
#if CONFIG_SOC_WIFI_SUPPORT_5G
    esp_err_t band_err = esp_wifi_set_band_mode(WIFI_BAND_MODE_5G_ONLY);
    if (band_err != ESP_OK) {
        ESP_LOGW(TAG, "Failed to set 5G-only band mode: %s", esp_err_to_name(band_err));
    }
#endif

    // Explicitly kick off the first connection attempt now that the band is locked.
    esp_err_t connect_err = esp_wifi_connect();
    if (connect_err != ESP_OK) {
        ESP_LOGW(TAG, "esp_wifi_connect() failed: %s", esp_err_to_name(connect_err));
    }

    // Wait for connection
    EventBits_t bits = xEventGroupWaitBits(_wifi_event_group,
                                           WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                           pdFALSE,
                                           pdFALSE,
                                           pdMS_TO_TICKS(timeoutMs));

    _connected = (bits & WIFI_CONNECTED_BIT) != 0;
    return _connected;
}

bool ESPWiFiManager::isConnected() {
    return _connected;
}

esp_ip4_addr_t ESPWiFiManager::getIP() {
    return _ip;
}

void ESPWiFiManager::maintain() {
    if (!_connected) {
        esp_wifi_connect();
    }
}