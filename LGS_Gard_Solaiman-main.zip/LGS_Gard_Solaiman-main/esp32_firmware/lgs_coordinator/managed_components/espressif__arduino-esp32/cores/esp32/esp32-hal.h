/*
 Arduino.h - Main include file for the Arduino SDK
 Copyright (c) 2005-2013 Arduino Team.  All right reserved.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef HAL_ESP32_HAL_H_
#define HAL_ESP32_HAL_H_

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>
#include <math.h>
#include "sdkconfig.h"
#include "esp_system.h"
#include "esp_sleep.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"

/**
 * DMA buffer alignment requirement for the current target.
 *
 * When a chip has an L2 cache, GDMA routes through it and the L2 cache-line
 * size is the binding alignment constraint for DMA buffers (both address and
 * size must be a multiple of this value). On chips with only an L1 cache the
 * L1 cache-line size applies. On chips without any DMA-relevant cache,
 * the DMA engine itself still requires 4-byte (word) alignment.
 */
#if defined(CONFIG_CACHE_L2_CACHE_LINE_SIZE)
#define ESP_ARDUINO_DMA_BUF_ALIGN CONFIG_CACHE_L2_CACHE_LINE_SIZE
#elif defined(CONFIG_CACHE_L1_CACHE_LINE_SIZE)
#define ESP_ARDUINO_DMA_BUF_ALIGN CONFIG_CACHE_L1_CACHE_LINE_SIZE
#else
#define ESP_ARDUINO_DMA_BUF_ALIGN 4
#endif

/** True when a pointer address is aligned to the DMA requirement. */
#define ESP_ARDUINO_DMA_IS_PTR_ALIGNED(ptr) (((uintptr_t)(ptr) & ((ESP_ARDUINO_DMA_BUF_ALIGN) - 1)) == 0)

/** True when a byte count is a multiple of the DMA alignment requirement. */
#define ESP_ARDUINO_DMA_IS_SIZE_ALIGNED(sz) (((sz) & ((ESP_ARDUINO_DMA_BUF_ALIGN) - 1)) == 0)

/* Compile-time check: the alignment value must be a power of two. */
_Static_assert(((ESP_ARDUINO_DMA_BUF_ALIGN) & ((ESP_ARDUINO_DMA_BUF_ALIGN)-1)) == 0, "ESP_ARDUINO_DMA_BUF_ALIGN must be a power of two");

#ifdef __cplusplus
extern "C" {
#endif

#ifndef F_CPU
#define F_CPU (CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ * 1000000U)
#endif

#if CONFIG_ARDUINO_ISR_IRAM
#define ARDUINO_ISR_ATTR IRAM_ATTR
#define ARDUINO_ISR_FLAG ESP_INTR_FLAG_IRAM
#else
#define ARDUINO_ISR_ATTR
#define ARDUINO_ISR_FLAG (0)
#endif

#ifndef ARDUINO_RUNNING_CORE
#define ARDUINO_RUNNING_CORE CONFIG_ARDUINO_RUNNING_CORE
#endif

#ifndef ARDUINO_EVENT_RUNNING_CORE
#define ARDUINO_EVENT_RUNNING_CORE CONFIG_ARDUINO_EVENT_RUNNING_CORE
#endif

#if CONFIG_IDF_TARGET_ESP32 || CONFIG_IDF_TARGET_ESP32S2 || CONFIG_IDF_TARGET_ESP32S3
static const uint8_t BOOT_PIN = 0;
#elif CONFIG_IDF_TARGET_ESP32C2 || CONFIG_IDF_TARGET_ESP32C3 || CONFIG_IDF_TARGET_ESP32C6 || CONFIG_IDF_TARGET_ESP32C61 || CONFIG_IDF_TARGET_ESP32H2 \
  || CONFIG_IDF_TARGET_ESP32C61
static const uint8_t BOOT_PIN = 9;
#elif CONFIG_IDF_TARGET_ESP32P4
static const uint8_t BOOT_PIN = 35;
#elif CONFIG_IDF_TARGET_ESP32C5
static const uint8_t BOOT_PIN = 28;
#else
#error BOOT_PIN not defined for this chip!
#endif
#define BOOT_PIN BOOT_PIN

//forward declaration from freertos/portmacro.h
void vPortYield(void);
void yield(void);
#define optimistic_yield(u)

#define ESP_REG(addr) *((volatile uint32_t *)(addr))
#define NOP()         asm volatile("nop")

#include "esp32-hal-log.h"
#include "esp32-hal-matrix.h"
#include "esp32-hal-uart.h"
#include "esp32-hal-gpio.h"
#include "esp32-hal-ldo.h"
#include "esp32-hal-touch.h"
#include "esp32-hal-touch-ng.h"
#include "esp32-hal-dac.h"
#include "esp32-hal-adc.h"
#include "esp32-hal-spi.h"
#include "esp32-hal-i2c.h"
#include "esp32-hal-ledc.h"
#include "esp32-hal-rmt.h"
#include "esp32-hal-sigmadelta.h"
#include "esp32-hal-timer.h"
#include "esp32-hal-bt.h"
#include "esp32-hal-psram.h"
#include "esp32-hal-rgb-led.h"
#include "esp32-hal-cpu.h"
#include "esp32-hal-hosted.h"

void analogWrite(uint8_t pin, int value);
void analogWriteFrequency(uint8_t pin, uint32_t freq);
void analogWriteResolution(uint8_t pin, uint8_t bits);

//returns chip temperature in Celsius
float temperatureRead();

//allows user to bypass SPI RAM test routine
bool testSPIRAM(void);

#if CONFIG_AUTOSTART_ARDUINO
//enable/disable WDT for Arduino's setup and loop functions
void enableLoopWDT();
void disableLoopWDT();
//feed WDT for the loop task
void feedLoopWDT();
#endif

//enable/disable WDT for the IDLE task on Core 0 (SYSTEM)
void enableCore0WDT();
bool disableCore0WDT();
#ifndef CONFIG_FREERTOS_UNICORE
//enable/disable WDT for the IDLE task on Core 1 (Arduino)
void enableCore1WDT();
bool disableCore1WDT();
#endif

//if xCoreID < 0 or CPU is unicore, it will use xTaskCreate, else xTaskCreatePinnedToCore
//allows to easily handle all possible situations without repetitive code
BaseType_t xTaskCreateUniversal(
  TaskFunction_t pxTaskCode, const char *const pcName, const uint32_t usStackDepth, void *const pvParameters, UBaseType_t uxPriority,
  TaskHandle_t *const pxCreatedTask, const BaseType_t xCoreID
);

unsigned long micros();
unsigned long millis();
void delay(uint32_t);
void delayMicroseconds(uint32_t us);

#if !CONFIG_ESP32_PHY_AUTO_INIT
void arduino_phy_init();
#endif

#if !CONFIG_AUTOSTART_ARDUINO
void initArduino();
#endif

typedef struct {
  int core;                    // core which triggered panic
  const char *reason;          // exception string
  const void *pc;              // instruction address that triggered the exception
  bool backtrace_corrupt;      // if backtrace is corrupt
  bool backtrace_continues;    // if backtrace continues, but did not fit
  unsigned int backtrace_len;  // number of backtrace addresses
  unsigned int backtrace[60];  // backtrace addresses array
} arduino_panic_info_t;

typedef void (*arduino_panic_handler_t)(arduino_panic_info_t *info, void *arg);

void set_arduino_panic_handler(arduino_panic_handler_t handler, void *arg);
arduino_panic_handler_t get_arduino_panic_handler(void);
void *get_arduino_panic_handler_arg(void);

#ifdef __cplusplus
}
#endif

#endif /* HAL_ESP32_HAL_H_ */
