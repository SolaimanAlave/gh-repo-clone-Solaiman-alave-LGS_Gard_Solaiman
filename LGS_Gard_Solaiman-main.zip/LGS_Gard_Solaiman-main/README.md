# LGS_Gard_Solaiman
LGS Gardener -  IoT Monitoring System with 3 ESP32-C5 devices
