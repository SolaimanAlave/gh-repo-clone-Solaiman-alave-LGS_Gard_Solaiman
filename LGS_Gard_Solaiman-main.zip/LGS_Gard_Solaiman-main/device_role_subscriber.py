"""
Device Role Subscriber - Listens for device role announcements and stores in database.
(Stage 2: coordinator self-election - writes device, role, and Zigbee config to Postgres)
"""

import paho.mqtt.client as mqtt
import json
import logging
import uuid
from database import DatabaseManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TOPIC_ROLE = "GardenerDeviceRole"


class DeviceRoleSubscriber:
    def __init__(self):
        self.db = DatabaseManager()

    def upsert_device(self, device_id, mac_address):
        """Insert the device if new, or update last_seen if it already exists."""
        query = """
            INSERT INTO devices (device_id, mac_address, last_seen, is_active)
            VALUES (%s, %s, now(), true)
            ON CONFLICT (device_id) DO UPDATE
                SET last_seen = now(),
                    is_active = true
        """
        with self.db.get_cursor() as cur:
            cur.execute(query, (device_id, mac_address))
            logger.info(f"✅ Device upserted: {device_id}")

    def upsert_role(self, device_id, role):
        """Insert or update this device's current role."""
        query = """
            INSERT INTO device_roles (device_id, role, last_heartbeat, updated_time)
            VALUES (%s, %s, now(), now())
            ON CONFLICT (device_id) DO UPDATE
                SET role = EXCLUDED.role,
                    last_heartbeat = now(),
                    updated_time = now()
        """
        with self.db.get_cursor() as cur:
            cur.execute(query, (device_id, role))
            logger.info(f"✅ Role upserted: {device_id} -> {role}")

    def insert_zigbee_config(self, pan_id, channel, coordinator_id):
        """Record the Zigbee network parameters announced by the coordinator."""
        query = """
            INSERT INTO zigbee_network_config (config_id, pan_id, channel, coordinator_id, updated_time)
            VALUES (%s, %s, %s, %s, now())
        """
        with self.db.get_cursor() as cur:
            cur.execute(query, (str(uuid.uuid4()), pan_id, channel, coordinator_id))
            logger.info(f"✅ Zigbee config recorded: PAN {pan_id}, channel {channel}")

    def insert_failover_event(self, device_id, new_role, details):
        """Log this role announcement in the audit trail."""
        query = """
            INSERT INTO failover_events (event_id, device_id, event_type, previous_role, new_role, details, created_time)
            VALUES (%s, %s, %s, %s, %s, %s, now())
        """
        with self.db.get_cursor() as cur:
            cur.execute(query, (str(uuid.uuid4()), device_id, "join", None, new_role, json.dumps(details)))
            logger.info(f"✅ Failover event logged: {device_id} joined as {new_role}")

    def on_message(self, client, userdata, msg):
        """Handle incoming MQTT role announcement messages."""
        try:
            data = json.loads(msg.payload.decode('utf-8'))
            device_id = data.get("device_id")
            role = data.get("role")
            pan_id = data.get("pan_id")
            channel = data.get("channel")

            logger.info(f"📨 Received role announcement from {device_id}: {role}")

            # device_id already encodes part of the real MAC; the firmware
            # doesn't currently send the full 6-byte MAC separately, so we
            # store device_id here too as the best available identifier.
            self.upsert_device(device_id, mac_address=device_id)
            self.upsert_role(device_id, role)

            if role == "coordinator" and pan_id is not None and channel is not None:
                self.insert_zigbee_config(pan_id, channel, coordinator_id=device_id)

            self.insert_failover_event(device_id, role, data)

        except Exception as e:
            logger.error(f"❌ Error processing role message: {e}")

    def start(self):
        """Start the MQTT subscriber."""
        client = mqtt.Client()
        client.on_message = self.on_message

        try:
            client.connect("localhost", 1883, 60)
            client.subscribe(TOPIC_ROLE)
            logger.info("✅ Subscriber connected to MQTT broker")
            logger.info(f"👂 Listening for device role messages on '{TOPIC_ROLE}'...")
            client.loop_forever()
        except KeyboardInterrupt:
            logger.info("🛑 Subscriber stopped")
        except Exception as e:
            logger.error(f"❌ Subscriber error: {e}")
        finally:
            client.disconnect()


if __name__ == "__main__":
    subscriber = DeviceRoleSubscriber()
    subscriber.start()
