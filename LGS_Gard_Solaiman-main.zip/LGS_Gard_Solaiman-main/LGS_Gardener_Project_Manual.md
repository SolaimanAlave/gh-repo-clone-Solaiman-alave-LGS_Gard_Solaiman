# LGS Gardener — Zigbee/MQTT Coordinator Failover System
## Project Manual: Stage 0 through Stage 9

**Project:** Vertical farming IoT system with automatic coordinator failover
**Hardware:** 3x ESP32-C5 boards (Device A, B, C)
**Repo:** `github.com/Solaiman-alave/LGS_Gard_Solaiman` (private)
**Status as of this manual:** Stages 0, 2–8 complete and hardware-tested. Stage 1 nearly complete (LED pattern pending). Stage 9 in progress.

---

## Architecture Overview

```
        OxyOS (backend)
              │ MQTT
              ▼
      Mosquitto Broker (Docker: lgs_mosquitto)
      ┌───────┼───────┐
   Device A  Device B  Device C     (ESP32-C5, each with Zigbee coordinator + sensors)
      │
      ▼
  Postgres (Docker: lgs_postgres) ◄── Orchestrator (Docker: lgs_orchestrator)
      │
  pgAdmin (Docker: lgs_pgadmin, browser UI at localhost:5050)
```

**MQTT Topics:**
| Topic | Publisher | Purpose |
|---|---|---|
| `GardenerSensorData` | each device | temp/humidity/water/pH/TDS readings (every 15s) |
| `GardenerHeartbeat` | each device | `{device_id, timestamp}` (every 10s) — proves device is alive |
| `GardenerDeviceRole` | each device | role announcement on boot: `{device_id, role, pan_id, channel, short_addr}` |
| `GardenerCommand` | orchestrator / `promote_device.py` | `{command:"promote_to_coordinator", target_device_id}` |

**Postgres tables (`gardener_db`):**
- `devices` — device_id, mac_address, last_seen, is_active
- `device_roles` — device_id, role (coordinator/candidate/member), last_heartbeat
- `zigbee_network_config` — pan_id, channel, coordinator_id, history of every coordinator's network params
- `failover_events` — full audit log: joins, timeouts, promotions, arbitration decisions

---

## Stage 0 — Infrastructure ✅ Done

**What was built:**
- `docker-compose.yml` with three services: `lgs_postgres`, `lgs_pgadmin`, `lgs_mosquitto`
- Postgres schema created via `stage0_schema.sql` — the four tables above
- pgAdmin connected and verified showing all tables

**Key bugs found and fixed:**
- **pgAdmin couldn't connect to Postgres** — its server entry had `Host name/address = localhost`, which is wrong because pgAdmin runs in its *own* container and `localhost` there means "itself," not the Postgres container. Fixed by changing the host to `lgs_postgres` (the container name — Docker's internal DNS resolves this).
- **Postgres password kept failing for pgAdmin** — the container's `POSTGRES_PASSWORD` env var only applies on first-ever database init, not on every restart, so the actual stored password could drift from the env var. Fixed by explicitly running `ALTER USER gardener_user WITH PASSWORD '...'` to force it.

**Verification:** confirmed via both `psql` command line and the pgAdmin GUI showing identical table contents.

---

## Stage 1 — Device A hardware + firmware ⏳ Nearly done

**Hardware:** USB→ESP32-C5, external LED: 3V3 → 220Ω resistor → LED(long leg) → LED(short leg) → GPIO2 (active-low: LED lights when GPIO2 is driven LOW).

**Firmware built:**
- Unique device ID generated from the chip's factory MAC address (`esp_read_mac`), formatted as `LGS_C5_XXXXXX` — guarantees every physical board gets a different, stable ID with zero manual configuration, and doubles as the MQTT client ID.
- WiFi connect (ESP-IDF native, via `ESPWiFiManager`)
- MQTT connect (`MqttManager`, built on PubSubClient)
- LED blink task on GPIO2 (currently a generic on/off blink — **not yet** a distinct "I am coordinator" pattern; this is the one remaining Stage 1 item)

**Major bugs found and fixed (this was the hardest debugging of the whole project):**

1. **WiFi crash loop on connection retry.** The ESP32-C5's WiFi driver would crash with a `Load access fault` whenever it fell back from 5GHz to 2.4GHz during a failed connection retry (visible in logs as `wifi:new:<1,0>, old:<44,0>`). Root cause: a driver-level bug in the regulatory-domain reprocessing that happens during a band switch. **Fix:** lock the radio to `WIFI_BAND_MODE_5G_ONLY` via `esp_wifi_set_band_mode()`, called right after `esp_wifi_start()` (this call requires WiFi to already be started). This removes the crash-triggering band-switch path entirely.

2. **MQTT payload/struct mismatch build failure.** Added `waterTemp`, `pH`, `tds` fields to `MqttManager.cpp`'s JSON payload before adding the matching fields to the `SensorData` struct in `MessageTypes.h` — this caused silent build failures for an extended period, during which the ESP32 kept running a stale binary while every test appeared to "do nothing." **Lesson:** always check `idf.py build` output directly rather than assuming a flash succeeded.

3. **Two "invisible" logging bugs.** `MqttManager.cpp`'s diagnostic messages used `Serial.printf`/`Serial.println` (Arduino-style), which never appears in the ESP-IDF `idf.py monitor` output when using Arduino-as-a-component. Converted all logging in `main.cpp` and `MqttManager.cpp` to `ESP_LOGI`/`ESP_LOGW`, which reliably shows up.

4. **Rogue native services stealing Docker's ports (the big one).** Both Mosquitto and Postgres had **native macOS installs** (a Homebrew `mosquitto` service, and a full **PostgreSQL 18** app in `/Applications`) that were silently binding to ports 1883 and 5432 *before* Docker could. This meant the ESP32 was successfully connecting and publishing to the native Mosquitto — never the Docker one — for an unknown period, while every `mosquitto_sub` test against the Docker container showed nothing. Diagnosed via `lsof -i :PORT` and `netstat -anv`. **Fixed** by stopping both native services permanently:
   ```bash
   brew services stop mosquitto
   sudo launchctl stop postgresql-18
   ```

5. **Postgres port not published to host after container restart.** `docker-compose.yml` correctly specified `"5432:5432"`, but the running container had been created before that config took effect, so `docker port lgs_postgres` showed nothing. Fixed with a full recreate: `docker compose stop postgres && docker compose rm -f postgres && docker compose up -d postgres`.

6. **Subnet mismatch.** Early on, the Mac and ESP32 were on completely different networks (ESP32 on "Temple" WiFi at `10.0.0.x`, Mac on a hotspot at `172.20.10.x`). MQTT_BROKER in `Config.h` must always match the Mac's actual IP on the *same* network the ESP32 connects to.

**Files:** `main.cpp`, `MqttManager.h/.cpp`, `esp_wifi_manager.cpp`, `Config.h`, `MessageTypes.h`, `SensorManager.cpp`

---

## Stage 2 — Device A self-elects as Coordinator ✅ Done

**What was built:**
- `taskAnnounceRole()` in `main.cpp`: ~5 seconds after the Zigbee network forms, publishes `{"device_id", "role":"coordinator", "pan_id", "channel", "short_addr"}` to `GardenerDeviceRole`, using the same `esp_zb_get_pan_id()` / `esp_zb_get_current_channel()` / `esp_zb_get_short_address()` calls the Zigbee logs already used.
- `device_role_subscriber.py` (later folded into `orchestrator.py`): subscribes to `GardenerDeviceRole`, writes the device into `devices`, `device_roles`, `zigbee_network_config`, and logs a `join` event to `failover_events`.

**Verified:** real Postgres rows confirmed matching the announced PAN ID/channel, both via `psql` and pgAdmin.

---

## Stage 3 — Orchestrator service ✅ Done

**What was built:** `orchestrator.py` — a long-running Python service (`paho-mqtt` + `psycopg2`) that:
- Subscribes to `GardenerHeartbeat` and `GardenerDeviceRole`
- Tracks each device's last-seen time in memory (`self.last_seen` dict, thread-safe via a lock)
- Runs a background watchdog thread (`watchdog_loop`) checking every 5 seconds: if a device hasn't sent a heartbeat in `HEARTBEAT_TIMEOUT_SEC` (30s), it's marked `is_active = false` in `devices`, demoted to `member` in `device_roles`, and a `timeout` event is logged.

**Firmware addition:** `GardenerHeartbeat` topic added — `main.cpp` publishes `{device_id, timestamp}` every `HEARTBEAT_INTERVAL_MS` (10s) from inside `taskPublishMqtt`.

**Verified live:** unplugged the ESP32, watched the orchestrator print `⏰ Device ... timed out - marked inactive` after ~30s, confirmed `is_active = false` in Postgres, then plugged it back in and confirmed it flipped back to `true` on the next heartbeat.

---

## Stage 4 — Add Device B ✅ Done

**What was built:** role arbitration logic in `orchestrator.py`'s `on_role_announcement()`:
- On any `coordinator` claim, query `get_active_coordinator(exclude_device_id)` — is there another device that's both `role='coordinator'` AND `is_active=true`?
- If yes → override the claim, assign `member` instead, and log the arbitration decision (`claimed_role` vs `assigned_role`) to `failover_events`.
- If no → accept the claim as-is.

**Important known limitation:** each device still forms its **own independent Zigbee network** (different PAN ID per device) — true single-mesh Zigbee joining (Device B joining Device A's actual radio network as a router) was never implemented. Role arbitration happens entirely at the MQTT/backend level, which is sufficient for everything tested so far but is a real architectural simplification worth knowing about.

**Verified live:** flashed identical firmware onto a second physical board (unique ID auto-generated: `LGS_C5_9D4C60`). Confirmed it was correctly demoted to `member` while Device A was active.

---

## Stage 5 — Manual failover ✅ Done

**What was built:**
1. **`promote_device.py`** — a standalone script simulating what OxyOS would eventually send: `python3 promote_device.py <target_device_id>` publishes `{"command":"promote_to_coordinator","target_device_id":...}` to `GardenerCommand`.
2. **Firmware command handling** (`main.cpp` + `MqttManager.h/.cpp`):
   - `MqttManager::setCommandCallback()` lets `main.cpp` register a handler for incoming MQTT messages.
   - **Critical concurrency fix:** the MQTT callback fires *inside* `_mqttClient.loop()`, which itself runs *inside* `MqttManager::maintain()` while the internal mutex is held. Calling `publish()` directly from the callback would try to re-take the same mutex and time out (a self-deadlock). Fixed by having the callback only set a `volatile bool g_pendingPromotion` flag; the actual `announceRole("coordinator")` re-publish happens in `taskPublishMqtt`'s main loop, *after* `maintain()` returns and releases the mutex.
3. **`mark_inactive()` in the orchestrator** was updated to also demote the timed-out device's stored `role` to `member` (previously only `is_active` was touched, which left the `device_roles` table showing two "coordinators" simultaneously and was misleading, even though arbitration logic was already functionally correct due to checking `is_active`).

**Verified live:** unplugged Device A (coordinator) → orchestrator detected timeout → ran `promote_device.py LGS_C5_9D4C60` → Device B received the command, re-announced as coordinator, arbitration accepted it (since A was inactive) → confirmed in Postgres. Also confirmed: when A was plugged back in, it correctly stayed `member` rather than reclaiming the role (stability over "first device wins" once a new coordinator is established).

---

## Stage 6 — Add Device C ✅ Done

**What was built:** nothing new in code — this stage was pure hardware/testing validation, confirming Stage 4's two-device arbitration logic scales correctly to three.

**Verified live:** flashed the identical firmware onto a third board (unique ID auto-generated: `LGS_C5_AA2ED4`). Confirmed a genuine three-node network: one coordinator, two members, all three visible simultaneously in both `psql` and the pgAdmin GUI.

**Minor hardware note:** Device C initially had its external LED wired incorrectly (leftover from a previous, unrelated project on that board) — not a firmware bug, fixed by correcting the physical wiring to match GPIO2/active-low, same as A and B.

---

## Stage 7 — Automatic failover ✅ Done

**What was built:** `auto_promote()` in `orchestrator.py`. Chosen design: **option (a)** from the original stage plan — the orchestrator itself (backend-authoritative) auto-selects and pushes the promotion, rather than (b) devices self-electing via their own protocol.

- `mark_inactive()` now checks, *before* demoting, whether the timed-out device's role **was** `coordinator` (via a new `get_role()` lookup).
- If so, calls `auto_promote(exclude_device_id)`, which:
  - `select_promotion_candidate()` — picks the most-recently-active *other* device (`ORDER BY last_seen DESC LIMIT 1`)
  - Publishes the exact same `promote_to_coordinator` command that `promote_device.py` sends manually — no human involved.
- If no candidate is found (all devices down), logs an `auto_failover_failed` event rather than silently doing nothing.

**Verified live, twice:** unplugged the coordinator → orchestrator automatically detected the timeout, selected a replacement, and promoted it, with zero manual commands. Also confirmed: when the original coordinator later rejoined, it was correctly kept as `member`, not allowed to disrupt the new stable coordinator.

---

## Stage 8 — Chaos test ✅ Core requirement done

**What was tested:** random coordinator kills across all three physical devices (A, B, and C each took a turn failing), including a rapid back-to-back scenario — killing the *newly promoted* coordinator immediately after the first auto-promotion, before anything had time to "settle."

**Result:** the system correctly cycled through two consecutive automatic promotions (C fails → B promoted → B fails immediately → A promoted) with no dual-coordinator conflicts and a consistent final database state.

**Real gap discovered (not yet a Stage 8 requirement, but surfaced by this testing):** at one point during testing, the `orchestrator.py` process itself had stopped running (likely closed accidentally), and — since nothing else watches for *that* — the whole failover system silently went dark: no detection, no promotion, database stuck showing no active coordinator, until a human noticed via `ps aux | grep orchestrator` and manually restarted it. This became the basis for the Stage 9 work below.

---

## Stage 9 — Hardening ⏳ In progress

**What was built:**
1. **Containerized the orchestrator.** New `Dockerfile.orchestrator`:
   ```dockerfile
   FROM python:3.12-slim
   WORKDIR /app
   COPY database.py orchestrator.py ./
   RUN pip install --no-cache-dir psycopg2-binary paho-mqtt
   CMD ["python", "orchestrator.py"]
   ```
2. **Added an `orchestrator` service to `docker-compose.yml`** with `restart: unless-stopped`, `depends_on: [postgres, mosquitto]`, and environment variables `DB_HOST=lgs_postgres`, `MQTT_HOST=lgs_mosquitto`.
3. **Made both `database.py` and `orchestrator.py` host-configurable** via environment variables, defaulting to `localhost` so the exact same files still work when run manually outside Docker (for quick debugging), without any code duplication:
   - `database.py`: `'host': __import__('os').environ.get('DB_HOST', 'localhost')`
   - `orchestrator.py`: `client.connect(__import__("os").environ.get("MQTT_HOST", "localhost"), 1883, 60)`

**Verified:** built and ran successfully as `lgs_orchestrator`, confirmed connecting to Postgres/Mosquitto via container names and processing all three devices' heartbeats correctly.

**Not fully proven:** attempts to test the `restart: unless-stopped` policy directly (`docker kill`, killing PID 1 from inside) did not trigger an observed restart — this is very likely because `docker kill`/`docker stop` are *always* treated by Docker as an intentional human stop (which `unless-stopped` is specifically designed to respect and not fight), not because the policy is broken. A true internal crash (unhandled exception in the running code) was not separately simulated and confirmed. This remains open if a fully rigorous proof is wanted later — see "Open Items" below.

**Still not started (explicitly listed in the original stage plan, not yet touched):**
- Device-side reboot persistence — an ESP32 reloading its last known role from the broker/DB on boot, rather than always announcing `coordinator` and relying entirely on backend arbitration
- ESP32-side reconnect/backoff logic hardening (WiFi/MQTT)
- Broker-down / DB-down behavior specifically from the device's perspective

---

## Still Open / Not Yet Done

1. **Stage 1:** LED should show a *distinct* pattern per role (e.g., solid vs. blinking differently for coordinator vs. member) — currently just a generic 500ms on/off blink regardless of role.
2. **Stage 9:** device-side reboot persistence, reconnect/backoff hardening, broker/DB-down device behavior.
3. **Stage 9 (nice-to-have):** a rigorous, repeatable test that the Docker `restart: unless-stopped` policy recovers from a genuine internal crash (not just a manual stop).
4. **Noted for later, deliberately deferred:** a four-LED actuator-simulation feature (water solenoid / grow light / fan / nutrient pump, each with a distinct blink pattern on GPIO2/10/15/18) — separate from the Stage 1 role-indicator LED, not part of the original stage tracker, saved as a future task.
5. **Security hygiene, not urgent since everything is local-only:** several credentials (Postgres password, pgAdmin password) were exposed in this chat session during debugging. Worth rotating eventually, especially before any move away from a fully local setup.

---

## Key Commands Reference

**Flash a device:**
```bash
cd esp32_firmware/lgs_coordinator
. $HOME/esp/esp-idf-v5.5.5/export.sh
idf.py -p /dev/cu.usbmodemXXXX build flash monitor
```

**Run the orchestrator (Docker — recommended, auto-restarts):**
```bash
docker compose up -d orchestrator
docker logs -f lgs_orchestrator
```

**Run the orchestrator (manual terminal — for interactive debugging; stop the Docker one first):**
```bash
docker compose stop orchestrator
source venv/bin/activate
python3 orchestrator.py
```

**Manually promote a device to coordinator:**
```bash
python3 promote_device.py <target_device_id>
```

**Check current roles/status:**
```bash
docker exec -it lgs_postgres psql -U gardener_user -d gardener_db \
  -c "SELECT d.device_id, r.role, d.is_active, d.last_seen FROM devices d JOIN device_roles r USING (device_id) ORDER BY d.device_id;"
```

**Check the audit trail:**
```bash
docker exec -it lgs_postgres psql -U gardener_user -d gardener_db \
  -c "SELECT * FROM failover_events ORDER BY created_time DESC LIMIT 10;"
```

**Watch live MQTT traffic on any topic:**
```bash
docker exec -it lgs_mosquitto mosquitto_sub -t GardenerHeartbeat -v
```

**Check all containers are healthy:**
```bash
docker ps
```

---

## Key Files

| File | Purpose |
|---|---|
| `esp32_firmware/lgs_coordinator/main/main.cpp` | Device firmware entry point: WiFi/MQTT/Zigbee bring-up, role announcement, heartbeat, command handling |
| `esp32_firmware/lgs_coordinator/main/MqttManager.h/.cpp` | Thread-safe MQTT publish/subscribe wrapper |
| `esp32_firmware/lgs_coordinator/main/esp_wifi_manager.cpp` | ESP-IDF native WiFi connection, 5GHz band lock |
| `esp32_firmware/lgs_coordinator/main/Config.h` | WiFi/MQTT/topic/timing configuration |
| `esp32_firmware/lgs_coordinator/main/MessageTypes.h` | `SensorData` struct definition |
| `orchestrator.py` | The backend brain: heartbeat tracking, timeout detection, role arbitration, auto-promotion |
| `promote_device.py` | Manual failover trigger script |
| `database.py` | Postgres connection manager (shared by orchestrator and other scripts) |
| `stage0_schema.sql` | Postgres schema definition |
| `docker-compose.yml` | All four services: postgres, pgadmin, mosquitto, orchestrator |
| `Dockerfile.orchestrator` | Container build for the orchestrator |
