"""
Database Connection Manager
"""

import psycopg2
from psycopg2 import sql, Error
import logging
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DB_CONFIG = {
    'host': __import__('os').environ.get('DB_HOST', 'localhost'),
    'port': 5432,
    'database': 'gardener_db',
    'user': 'gardener_user',
    'password': 'vertical2026'
}
DB_TIMEOUT = 10

class DatabaseManager:
    def __init__(self):
        self.config = DB_CONFIG
        self.timeout = DB_TIMEOUT
    
    def connect(self):
        try:
            conn = psycopg2.connect(
                host=self.config['host'],
                port=self.config['port'],
                database=self.config['database'],
                user=self.config['user'],
                password=self.config['password'],
                connect_timeout=self.timeout
            )
            logger.info(f"Connected to database: {self.config['database']}")
            return conn
        except Error as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        conn = None
        try:
            conn = self.connect()
            yield conn
            conn.commit()
            logger.debug("Transaction committed")
        except Error as e:
            if conn:
                conn.rollback()
            logger.error(f"Transaction rolled back: {e}")
            raise
        finally:
            if conn:
                conn.close()
                logger.debug("Connection closed")
    
    @contextmanager
    def get_cursor(self, commit: bool = True):
        conn = None
        cursor = None
        try:
            conn = self.connect()
            cursor = conn.cursor()
            yield cursor
            if commit:
                conn.commit()
                logger.debug("Transaction committed")
        except Error as e:
            if conn:
                conn.rollback()
            logger.error(f"Cursor operation failed: {e}")
            raise
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    
    def execute_query(self, query: str, params: tuple = (), fetch: str = None):
        try:
            with self.get_cursor() as cursor:
                cursor.execute(query, params)
                if fetch == 'one':
                    return cursor.fetchone()
                elif fetch == 'all':
                    return cursor.fetchall()
                else:
                    return cursor.rowcount
        except Error as e:
            logger.error(f"Query execution failed: {e}")
            raise
